from flask import Flask, render_template

app = Flask(__name__)

#【目标1】：创建路由，路由的资源地址为'/calorie'，返回卡路里大挑战页面'calorie/calorie.html'
@app.route('/calorie')
def index():
    return render_template('calorie/calorie.html')

if __name__ == '__main__':
    app.run()
